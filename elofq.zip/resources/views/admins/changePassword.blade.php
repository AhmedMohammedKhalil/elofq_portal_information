@extends('admins.layout')
@section('section')
    <livewire:admin.change-password />
@endsection

