@extends('admins.layout',['page_name'=>'إضافة حصة جديدة'])

@section('section')
    <livewire:admin.sessions.add />
@endsection
