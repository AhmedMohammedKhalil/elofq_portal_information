@extends('admins.layout',['page_name'=>'إضافة كتاب جديد'])

@section('section')
    <livewire:admin.book.add />
@endsection
