@extends('admins.layout',['page_name'=>'إضافة فصل جديد'])

@section('section')
    <livewire:admin.classes.add/>
@endsection
