@extends('layouts.app')
@section('main')
    <div class="page-title-area bg-10" style="margin-top: 100px">
        <div class="container">
            <div class="page-title-content">
                <h2>تسجيل الدخول</h2>
            </div>
        </div>
    </div>
    <livewire:admin.login />
@endsection
