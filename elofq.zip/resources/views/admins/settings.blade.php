@extends('admins.layout')
@section('section')
    <livewire:admin.settings />
@endsection
