@extends('admins.layout',['page_name'=>'إضافة قسم جديد'])

@section('section')
    <livewire:admin.departments.add/>
@endsection
