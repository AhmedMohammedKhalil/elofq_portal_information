<div class="widget-sidebar">
    <div class="sidebar-widget categories">
        <ul>
            <li>
                <a href="{{ route('admin.dashboard') }}">الإحصائيات</a>
            </li>
            <li>
                <a href="{{ route('admin.book.index') }}">إدارة الكتب</a>
            </li>

            <li>
                <a href="{{ route('admin.class.index') }}">إدارة الصفوف</a>
            </li>

            <li>
                <a href="{{ route('admin.department.index') }}">إدارة الأقسام</a>
            </li>

            <li>
                <a href="{{ route('admin.teacher.index') }}">إدارة المعلمين</a>
            </li>

            <li>
                <a href="{{ route('admin.session.index') }}">إدارة الحصص</a>
            </li>

            <li>
                <a href="{{ route('admin.about.index') }}">إدارة من نحن</a>
            </li>

            <li>
                <a href="{{ route('admin.service.index') }}">إدارة الخدمات</a>
            </li>

            <li>
                <a href="{{ route('admin.slider.index') }}">إدارة السلايدر</a>
            </li>

            <li>
                <a href="{{ route('admin.profile') }}">البروفايل</a>
            </li>
            <li>
                <a href="{{ route('admin.settings') }}">تعديل البيانات الشخصية</a>
            </li>
            <li>
                <a href="{{ route('admin.changePassword') }}">تغيير كلمة السر</a>
            </li>
            <li>
                <a href="{{ route('admin.logout') }}">خروج</a>
            </li>

        </ul>
    </div>
</div>
