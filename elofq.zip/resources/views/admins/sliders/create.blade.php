@extends('admins.layout',['page_name'=>'إضافة سلايدر جديد'])

@section('section')
    <livewire:admin.sliders.add/>
@endsection
