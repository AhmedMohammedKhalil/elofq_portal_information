@extends('admins.layout',['page_name'=>'إضافة معلم جديد'])

@section('section')
    <livewire:admin.teachers.add/>
@endsection
