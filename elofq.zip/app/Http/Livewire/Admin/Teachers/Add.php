<?php

namespace App\Http\Livewire\Admin\Teachers;

use App\Models\Department;
use App\Models\Teacher;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\File;

class Add extends Component
{

    public $name, $phone, $c_number, $department_id, $departments, $image;
    use WithFileUploads;
    protected $messages = [
        'required' => 'ممنوع ترك الحقل فارغاَ',
        'phone.min' => 'لابد ان يكون الموبايل مكون من 8 ارقام',
        'phone.max' => 'لابد ان يكون الموبايل مكون من 8 ارقام',
        'c_number.min' => 'لابد ان يكون الرقم المدني مكون من 12 ارقام',
        'c_number.max' => 'لابد ان يكون الرقم المدني مكون من 12 ارقام',
        'image' => 'لابد ان يكون الملف صورة',
        'mimes' => 'لابد ان يكون الصورة jpeg,jpg,png',
        'image.max' => 'يجب ان تكون الصورة اصغر من 2 ميجا',
        'phone.unique' => 'هذا الموبايل مسجل فى الموقع',
        'c_number.unique' => 'هذا الرقم مسجل فى الموقع',
        'gt' => 'يجب اختيار القسم',
        'numeric' => 'يجب ان يكون الموبايل رقم'
    ];

    protected $rules = [
        'name' => ['required', 'max:255'],
        'phone' => ['required','regex:/^([0-9\s\-\+\(\)]*)$/','unique:teachers,phone','max:8','min:8'],
        'c_number' => ['required','regex:/^([0-9\s\-\+\(\)]*)$/','unique:teachers,c_number','max:12','min:12'],
        'department_id' => ['required','gt:0'],
        'image' => ['image', 'mimes:jpeg,jpg,png', 'max:2048']
    ];

    public function updatedImage()
    {
        $validatedata = $this->validate(
            ['image' => ['image', 'mimes:jpeg,jpg,png', 'max:2048']]
        );
    }

    public function add()
    {
        $validatedata = $this->validate();
        $imagename = $this->image->getClientOriginalName();
        $teacher = Teacher::create(array_merge($validatedata, ['image' => $imagename]));
        $dir = public_path('img/teachers/' . $teacher->id);
        if (file_exists($dir))
            File::deleteDirectory($dir);
        mkdir($dir);
        $this->image->storeAs('teachers/' . $teacher->id, $imagename);
        File::deleteDirectory(public_path('img/livewire-tmp'));

        session()->flash('message', "تم إتمام العملية بنجاح");
        return redirect()->route('admin.teacher.index');
    }
    public function render()
    {
        $this->departments = Department::select('id','title')->get();
        return view('livewire.admin.teachers.add');
    }
}
