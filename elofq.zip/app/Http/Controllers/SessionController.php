<?php

namespace App\Http\Controllers;

use App\Models\Session;
use Illuminate\Http\Request;

class SessionController extends Controller
{
    public function index()
    {
        return view('admins.sessions.index');
    }


    public function create()
    {
        return view('admins.sessions.create');
    }

    public function edit(Request $r)
    {
        return view('admins.sessions.edit',['session_id'=>$r->id]);
    }



    public function delete(Request $r)
    {
        Session::whereId($r->id)->delete();
        return redirect()->route('admin.session.index');
    }
}
